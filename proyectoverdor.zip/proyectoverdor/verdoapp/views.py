from django.shortcuts import render
from .models import Genero, User
# Create your views here.

def index(request):
    context={}
    return render(request, 'verdoapp/Vista_inicio.html', context)

def login(request):
    return render(request, 'verdoapp/login.html')

def crud(request):
    return render(request, 'verdoapp/usuarios_listar.html')

def registro(request):
    if request.method != "POST":
        generos=Genero.objects.all()
        context={'generos' : generos}
        return render(request, 'verdoapp/registro.html', context)
    else:
        correo=request.POST["email"]
        contraseña=request.POST["contraseña"]
        nombre=request.POST["nombre"]
        Apaterno=request.POST["appaterno"]
        Amaterno=request.POST["apmaterno"]
        fechaNac=request.POST["fechanac"]
        rut = request.POST["rut"]
        genero=request.POST["genero"]
        telefono=request.POST["telefono"]
        activo="1"

        objGenero=Genero.objects.get(id_genero = genero)
        obj=User.objects.create(    correo=correo,
                                    contraseña=contraseña,
                                    nombre=nombre,
                                    apellido_paterno=Apaterno,
                                    apellido_materno=Amaterno,
                                    fecha_nacimiento=fechaNac,
                                    rut=rut,
                                    id_genero=objGenero,
                                    telefono=telefono,
                                    activo=1 )
        obj.save()
        context = {'mensaje': "Ok, datos grabados..."}
    return render(request, 'verdoapp/registro.html', context)
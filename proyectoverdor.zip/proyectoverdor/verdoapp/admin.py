from django.contrib import admin
from .models import Genero, User

# Register your models here.

admin.site.register(Genero)
admin.site.register(User)
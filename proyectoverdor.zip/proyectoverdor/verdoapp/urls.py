from django.urls import path
from . import views

urlpatterns = [
    path('Vista_inicio', views.index, name='Vista_inicio'),
    path('login/', views.login, name='login'),
    path('registro/', views.registro, name='registro'),
    path('usuarios_listar/', views.crud, name='usuarios_listar'),
]
